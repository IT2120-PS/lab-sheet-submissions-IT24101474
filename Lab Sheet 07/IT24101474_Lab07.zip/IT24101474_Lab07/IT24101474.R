# Question 1

a <- 0
b <- 40
prob_q1 <- punif(25, min = a, max = b) - punif(10, min = a, max = b)
cat("probability the train arrives between 8:10 and 8:25 =", prob_q1, "\n")

# Question 2

lambda <- 1/3
prob_q2 <- pexp(2, rate = lambda)
cat("probability the update takes at most 2 hours =", prob_q2, "\n")

# Question 3

mean_iq <- 100
sd_iq <- 15

# i)probability that a randomly selected person has an IQ above 130

prob_q3_i <- 1 - pnorm(130, mean = mean_iq, sd = sd_iq)
cat("Probability IQ > 130 =", prob_q3_i, "\n")

# ii)  IQ score at 95th percentile

iq_95 <- qnorm(0.95, mean = mean_iq, sd = sd_iq)
cat("95th percentile IQ score =", iq_95, "\n")
