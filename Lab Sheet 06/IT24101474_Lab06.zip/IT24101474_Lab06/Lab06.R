# Problem 1
n <- 50
p <- 0.85


# distribution: Binomial(n,p)
# probability that at least 47 passed:
prob_at_least_47 <- 1 - pbinom(46, size = n, prob = p)
print(prob_at_least_47)

# same using sum of dbinom:
sum_prob <- sum(dbinom(47:50, size = n, prob = p))
print(sum_prob)

# Problem 2
lambda <- 12

# Poisson(lambda)
# probability exactly 15 calls:
prob_15 <- dpois(15, lambda = lambda)
print(prob_15)
